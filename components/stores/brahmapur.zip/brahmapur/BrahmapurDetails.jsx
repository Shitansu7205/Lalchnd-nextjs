"use client";
import React, { useState } from "react";
import ProgressBarComponent from "../../common/Progressbar";
import { useContextElement } from "@/context/Context";
import Slider2 from "@/components/product-details/sliders/Slider2";
import { storeLocations } from "@/data/storeDetails";
import { ArrowRight, Rotate3D } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
export default function BrahmapurDetails() {
    const [activeColor, setActiveColor] = useState("gold");
    const [quantity, setQuantity] = useState(1);
    const {
        addProductToCart,
        isAddedToCartProducts,

        cartProducts,
        updateQuantity,
    } = useContextElement();
    return (
        <>
        <link rel="stylesheet" href="/css/store/innerstore.css" />
        <section className="themesFlat section-padding-top-40">
            <div className="tf-main-product section-image-zoom">
                <div className="container-full-2">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="tf-product-media-wrap sticky-top">
                                <div className="thumbs-slider thumbs-right">
                                    <div className="image">
                                        <Image
                                            alt="Banner"
                                            loading="lazy"
                                            width={1000}
                                            height={900}
                                            className="lazyload"
                                            src="/images/lalchnd/store/berhampur/2.jpg"
                                            style={{ color: "transparent" }}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="tf-product-info-wrap">
                                <div className="tf-zoom-main sticky-top" />
                                <div className="tf-product-info-list other-image-zoom">
                                    <div className="tf-product-info-heading">
                                        <ul className="product-info-rate rate-wrap golden-star">
                                            <li>
                                                <i className="icon-star" />
                                            </li>
                                            <li>
                                                <i className="icon-star" />
                                            </li>
                                            <li>
                                                <i className="icon-star" />
                                            </li>
                                            <li>
                                                <i className="icon-star" />
                                            </li>
                                            <li>
                                                <i className="icon-star" />
                                            </li>
                                        </ul>
                                        <h3>
                                           Unveiling the Best Jewellery Shops and Gold Showrooms in <span className="highlight-font" style={{fontSize: "38px"}}>Brahmapur</span> - Lalchnd Jewellers 
                                        </h3>
                                        <p className="sub-title">
                                           Welcome to Lalchnd Jewellers, your go-to destination for exquisite jewellery in Brahmapur! We take pride in being recognized as the best jewellery shop in the city, offering a wide array of stunning options to cater to your discerning taste. At Lalchnd Jewellers, we are synonymous with quality, craftsmanship, and a commitment to providing the finest pieces for every occasion. Our Gold Jewellery Shop in Brahmapur stands out as a beacon of luxury and elegance. We understand that jewellery is not just an accessory; it’s an expression of your style and personality. With this in mind, our collection is thoughtfully curated to meet the diverse preferences of our valued customers.
<br /><br />As the <a href="/"><b>Best Jewellery Shopping Store in Brahmapur</b></a>, Lalchnd Jewellers takes pride in offering a seamless and enjoyable shopping experience. Whether you’re searching for the ideal engagement ring, a gift for a loved one, or a piece to mark a special milestone, our collection has something for everyone.
When it comes to Jewellery Shops in Brahmapur, Lalchnd Jewellers is the name that stands out. We are honored to be recognized as the Best Jewellers in Brahmapur, and our Gold Showroom in Brahmapur is a testament to the legacy we’ve built over the years.

                                        </p>


                                    </div>

                                    <div className="tf-product-share">
                                        <ul className="tf-social-icon">
                                            <li>
                                                <a href="https://www.facebook.com/LalchndJewellersPvtLtd" className="social-facebook">
                                                    <span className="icon">
                                                        <i className="icon-facebook" />
                                                    </span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="https://www.instagram.com/lalchnd.jewellers/" className="social-instagram">
                                                    <span className="icon">
                                                        <i className="icon-instagram" />
                                                    </span>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="https://www.youtube.com/channel/UCrO61El0o9WsM3fw3r7lolw" >
                                                    <span className="icon">
                                                        <svg
                                                            width="20"
                                                            height="20"
                                                            viewBox="0 0 24 24"
                                                            fill="currentColor"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            aria-hidden="true"
                                                        >
                                                            <path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8ZM9.6 15.6V8.4l6.3 3.6-6.3 3.6Z" />
                                                        </svg>
                                                    </span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                    <div className="section-padding-top-40 store-action-buttons">
                                        <ul className="entry_tag tag-wrap d-flex align-items-center inner-btn">
                                            <li className="inner-page-btn">
                                                <Link
                                                    href="https://www.google.com/search?sca_esv=9d147917e498fe61&sxsrf=APpeQnuVtIAHDuReqb9K7KNTaap-_NIt4g:1792227560098&si=APenkKm7iecQ4G6P-TsbSMFKIQtv3EFIqRAFw-i8uEbk55Z-_92vYRsQh5l6qz2s2Vq2oMvl8OpADnpCNv8s0trz-gM3oYXxqYTcoeNGPqZHX1MOokBFghSXFSK218PploBbHsZJOR0zzAvvwxBQ0bThJUdyWAXStw%3D%3D&q=Lalchnd+Jewellers+Reviews&sa=X&ved=2ahUKEwjJzs3418CXAxXT1zgGHe4cArsQ0bkNegQILBAI&biw=1517&bih=674&dpr=0.9#lrd=0x3a3d512e59d1b0fd:0xe6ddc87d80f14020,3,,,,"
                                                   className="home-cta-btn tf-btn btn-fill animate-btn type-large" target="_blank" rel="noopener noreferrer"
                                                style={{width: "100%"}}
                                                >
                                                    Write a Review
                                                    <ArrowRight size={24} strokeWidth={1.8} />
                                                </Link>
                                            </li>

                                            <li className="inner-page-btn">
                                                <Link
                                                    href="https://www.google.com/local/place/fid/0x3a3d512e59d1b0fd:0xe6ddc87d80f14020/photosphere?iu=https://streetviewpixels-pa.googleapis.com/v1/thumbnail?panoid%3DPlR3NC0SuK1IQDvaALmyiQ%26cb_client%3Dsearch.gws-prod.gps%26yaw%3D70.50755%26pitch%3D0%26thumbfov%3D100%26w%3D0%26h%3D0&ik=CAISFlBsUjNOQzBTdUsxSVFEdmFBTG15aVE%3D&sa=X&ved=2ahUKEwjDrYWnqPWWAxXXleEIHWZ6KPIQpx96BAgdEBI"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="tf-btn btn-fill-white store-map-button"
                                                >
                                                    360° View
                                                    <Rotate3D size={24} strokeWidth={1.8} />
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        </>
    );
}
