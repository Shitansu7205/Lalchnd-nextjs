import BreadcrumbBanner from "@/components/common/BreadcrumbBanner";
import React from "react";
import Footer2 from "@/components/footers/Footer2";
import StoreMastercanteen from "@/components/pay-online/StoreMastercanteen";
import Header from "@/components/headers/Header";
import TopBar from "@/components/headers/TopBar";
import Link from "next/link";
import Partion from "@/components/common/Partion";
import Topbar1 from "@/components/headers/Topbar1";
export const metadata = {
  title: "Lalchnd Master Canteen Store | Online Payment & Monthly Scheme",
  description: "Online advance payment and monthly jewellery scheme options available at Lalchnd Master Canteen store in Bhubaneswar.",
  alternates: {
    canonical: "https://lalchnd.com/store-mastercanteen",
  },
};
export default function page() {
  return (
    <>
      <div className="bg-surface">
        <div id="wrapper">
          <Topbar1 />
          <Header />
          <BreadcrumbBanner
          className="pay-online-banner"
            title="Pay Online"
            current="Master Canteen"
            image="/images/lalchnd/banner/pay-online-banner.webp"
          />
          <Partion />
          <StoreMastercanteen />
          <Footer2 />
        </div>
      </div>
    </>
  );
}
